def binaryTodecimal(n):
    decimal = 0
    power = 1
    while n>0:
        rem = n%10
        n = n//10
        decimal+=rem*power
        power = power*2
    return decimal
n=int(input("Enter a binary number"))
decimal_result=binaryTodecimal(n)
print(f"The decimal eluivalant of binary is {decimal_result}")

def octal_to_hexadecimal(octal):
    decimal = 0
    power = 0
    while octal>0:
        decimal+=(octal%10)*(8**power)
        octal//=10
        power+=1

    hexadecimal =" "
    while decimal>0:
        reminder=decimal%16
        if reminder<10:
            hexadecimal=str(reminder)+hexadecimal
        else:
            hexadecimal=chr(ord('A')+reminder-10)+hexadecimal
        decimal //=16
    return hexadecimal

octal=int(input("Enter a octal number:"))
hexadecimal_result=octal_to_hexadecimal(octal)

print(f"The hexadecimal equivalent of {octal} is {hexadecimal_result}")
