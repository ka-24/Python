marks1=int(input("Enter the marks of first test:"))
marks2=int(input("Enter the marks of second test:"))
marks3=int(input("Enter the marks of third test:"))
minimum=min(marks1,marks2,marks3)
sumofbest2=marks1+marks2+marks3-minimum
avgofbest2=sumofbest2/2
print("Avarage of best two:",avgofbest2)

             
