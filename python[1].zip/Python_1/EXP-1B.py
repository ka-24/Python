num=input("Enter the number:")


if num==num[::-1]:
   print("the number is palindrome")
else:
    print("the number is not palindrome")


cont={}
for digit in num:
    if digit in cont:
        cont [digit]+=1
    else:
        cont[digit]=1

print("Number of accurrance of is digit:")
for digit,count in cont.items():
    print(f"accurrance of {digit} is {count}:")
