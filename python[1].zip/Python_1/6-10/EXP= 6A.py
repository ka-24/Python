


fname = input("Enter the file name:")
try:
    fhand = open(fname,'r')
    linelist = fhand.readlines()
    for i in range(5):
        print(i+1,":",linelist[i])
    word = input("Enter a word:")
    cnt = 0
    for line in linelist:
        words = line.split()
        for i in words:
            if(i==word):
                cnt=cnt+1
    print("The word",word,"appears")
    print(cnt)
    
except:
    print("File",fname,"does not exists")







