import math

class Shape:
    def __init__(self):
        pass
        
    
        
class Circle(Shape):
    def __init__(self,radius):
       
        self.radius = radius
        
    def calcArea(self):
        return math.pi * self.radius * self.radius
    
class Rectangle(Shape):
    def __init__(self,length,breadth):
        
        self.length = length
        self.breadth = breadth
        
    def calcArea(self):
        return self.length * self.breadth

class Triangle(Shape):
    def __init__(self,base,height):
        
        self.base = base
        self.height = height
        
    def calcArea(self):
        return self.base * self.height / 2
        
def main():
    print("Enter the dimension of the Triangle")
    base=float(input("Base :"))
    height=float(input("height :"))
    triangle=Triangle(base,height)
    print("Area of triangle:",triangle.calcArea())
    
    print("\nEnter the radius of circle:")
    radius= float(input("radius :"))
    circle=Circle(radius)
    print("Area of the circle:",circle.calcArea())
    
    print("\nEnter the dimension of the rectangle")
    length=float(input("length :"))
    breadth=float(input("breadth :"))
    rectangle=Rectangle(length,breadth)
    print("Area of rectangle:",rectangle.calcArea())
    
    
    
if __name__=="__main__":
    main()