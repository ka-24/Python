

from PyPDF2 import PdfWriter, PdfReader
num = int(input("Enter page number you want to combine from multilpe documents"))

Pdf1 = open('birds.pdf','rb')
Pdf2 = open('cse.pdf','rb')
pdf_writer = PdfWriter()

Pdf1_reader = PdfReader(Pdf1)
page = Pdf1_reader.pages[num-1]
pdf_writer.add_page(page)

Pdf2_reader = PdfReader(Pdf2)
page = Pdf2_reader.pages[num-1]
pdf_writer.add_page(page)

with open('output.pdf','wb')as output:
    pdf_writer.write(output)