class Employee:
    def __init__ (self):
        self.name = " "
        self.empID = " "
        self.salary = 0
        
    def getEmpDetails(self):
        self.name = input("Enter Employee name:")
        self.empID = input("Enter Employee ID:")
        self.dept = input("Enter Employee Dept")
        self.salary = int(input("Enter Employee salary:"))
        
    def showEmpDetails(self):
        print("Employee Details")
        print("Name :",self.name)
        print("ID:",self.empID)
        print("salary:",self.salary)
        
    def updtsalary(self):
        self.salary = int(input("Enter new salary:"))
        print("Updated salary",self.salary)
        
el = Employee()
el.getEmpDetails()
el.showEmpDetails()
el.updtsalary()
