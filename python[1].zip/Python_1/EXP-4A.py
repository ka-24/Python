def insertion_sort(alist):
    for i in range(1,len(alist)):
        temp=alist[i]
        j=i-1
        while(j>=0 and temp<alist[j]):
            alist[j+1]=alist[j]
            j=j-1
        alist[j+1]=temp

alist=input("Enter the List of Numbers:").split()
alist=[int(x)for x in alist]

insertion_sort(alist)
print("Sorted List using Insertion sort:",end='')
print (alist)


def mergesort(alist):
    if len(alist)>1:
        mid=len(alist)//2
        left=alist[:mid]
        right=alist[mid:]
        mergesort(left)
        mergesort(right)
        i=0
        j=0
        k=0
        while i<len(left) and j<len(right):
            if left[i]<right[j]:
                alist[k]=left[i]
                i=i+1
                k=k+1
            else:
                alist[k]=right[j]
                j=j+1
                k=k+1
        while i<len(left):
            alist[k]=left[i]
            i=i+1
            k=k+1
        while j<len(right):
            alist[k]=right[j]
            j=j+1
            k=k+1
alist=input("enter the list of values to be sorted:").split()
alist=[int(x) for x in alist]
mergesort(alist)
print("Sorted List using Merge Sort",alist)
