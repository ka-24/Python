str1=input("Enter the string:")
LowerC=0
UpperC=0
DigitC=0

wordList=str1.split(" ")
print("this str1 has",len(wordList),"words")
for character in str1:
    if character.islower():
        LowerC=LowerC+1
    elif character.isupper():
        UpperC=UpperC+1
    elif character.isdigit():
        DigitC=DigitC+1
    else:
        print("other symbol")
    
print("Lower Count:",LowerC)
print("Upper Count:",UpperC)
print("Digit Count:",DigitC)

